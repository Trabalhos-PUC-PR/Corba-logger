#include <iostream>
#include <fstream>
#include <string>
#include "LoggerI.h"
#include <orbsvcs/CosNamingC.h>

// (para simplificar o programa, porém nem sempre recomendável)
using namespace std;
using namespace CORBA;
using namespace PortableServer;
using namespace CosNaming;

// ORB global
ORB_var orb = ORB::_nil();

int main(int argc, char* argv[])
{
    // Verifica parametros da linha de comando
    if (argc < 2) {
		cerr << "USO: " << argv[0] << " <arq_ior>" << endl;
		return 1;
    }

    try {

		// 1. Inicia ORB
		cout << "Inciando ORB" << endl;
		orb = ORB_init(argc,argv,"ORB");

		// 2. Ativa RootPOA
	    cout <<  "Ativando RootPOA" << endl;
		POA_var root_poa;
		Object_ptr tmp_ref;
		tmp_ref = orb->resolve_initial_references("RootPOA");
		root_poa = POA::_narrow(tmp_ref); // safe casting
		POAManager_var poa_manager = root_poa->the_POAManager();
		poa_manager->activate();

		// 3. Instancia "servants"
		cout << "Instanciando servant" << endl;
		Logger_i acc_i; // account name = ior file name

		// 4. Registra servos no POA, criando objetos distribuídos
		cout << "Registrando servos no POA (criando objetos CORBA)" << endl;
		Logger_var account = acc_i._this(); // returns reference to the object

		// 5. Publica IOR
		/*cout <<  "Publicando IOR (arquivo \"" << argv[1] << "\")" << endl;
		String_var ior = orb->object_to_string(account.in());
		ofstream arq_ior(argv[1]);
		arq_ior << ior << endl;
		arq_ior.close();*/
		
		
		tmp_ref = orb->resolve_initial_references("NameService");
		NamingContext_var sn = NamingContext::_narrow(tmp_ref);
		
		Name nome(1);
		nome.length(1);
		nome[0].id = string_dup(argv[1]);
		sn->rebind(nome, account.in());
		cout << argv[1] << " publicado\n";
		
		
		
		// 6. Aguarda requisições
		cout << "Aguardando requisicoes...\n" << endl;
		orb->run();

		// 7. Finaliza
		root_poa->destroy(true,true);
		orb->destroy();

    } catch (CORBA::Exception& e) {
		cerr << "CORBA exception: " << e << endl;
    }

    return 0;
}
