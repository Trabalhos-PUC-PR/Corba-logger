#include <iostream>
#include <string>
#include "LoggerC.h"
#include <orbsvcs/CosNamingC.h>
#include<cstdlib>
#include <chrono>
#include <format>

using namespace std;
using namespace CORBA;
using namespace CosNaming;


int main(int argc, char* argv[])
{
	if (argc < 2) {
		cerr << "USO: " << argv[0] << " file://<ior_file>" << endl;
		return 1;
	}

	try {
	
	srand((unsigned) time(NULL));

	// Get a random number
	int id = rand();
	string id_porta = to_string(rand()) + ":" + to_string(rand());
	
	// 1. Inicializa ORB
	ORB_var orb = ORB_init(argc,argv,"ORB");

	// 2. Obtém referência para o objeto distribuído
	Object_ptr ref;
	Logger_var logger;

	// ref = orb->string_to_object(argv[1]);
        ref = orb->resolve_initial_references("NameService");
        NamingContext_var sn = NamingContext::_narrow(ref);

        Name nome(1);
        nome.length(1);
        nome[0].id = string_dup(argv[1]);	

        ref = sn->resolve(nome);

	logger = Logger::_narrow(ref);

	string cmd;


	cout << "Comandos:\n\tlog\n\tverbose (alterar valor)\n\tfim" << endl;

	do {
		cout << "> ";
		cin >> cmd;
		if (cmd == "verbose"){
			bool alteracao = !logger->verbose();
			logger->verbose(alteracao);
		}else if (cmd == "log"){
			srand((unsigned) time(NULL));
			const auto now = std::chrono::system_clock::now();
			logger->log(1 + (rand() % 3), id_porta, id, format("{:%d-%m-%Y %H:%M:%OS}", now), "Mensagem de erro!");
		}
		
		
		
	}while (cmd != "fim");

	// 4. Destroi ORB
	orb->destroy();
	} catch (CORBA::Exception& e) {
		cerr << "CORBA EXCEPTION:" << e << endl;
	}

	return 0;
}

